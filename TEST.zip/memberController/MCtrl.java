package memberController;

import java.util.ArrayList;
import java.util.Iterator;

import memberModel.MDAO;
import memberModel.MVO;

public class MCtrl {

	private MDAO md = new MDAO();

	public MCtrl() {
	}

	public void memberAll() {
		ArrayList<MVO> aList = new ArrayList<MVO>();
		aList = md.memberAll();

		Iterator<MVO> it = aList.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
