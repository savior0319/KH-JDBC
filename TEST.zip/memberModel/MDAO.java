package memberModel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MDAO {

	private Connection conn = null;
	private Statement stmt = null;
	private ResultSet rs = null;
	private ArrayList<MVO> aList = new ArrayList<MVO>();

	public MDAO() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "TEST", "TEST");
			stmt = conn.createStatement();
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public ArrayList<MVO> memberAll() {
		String query = "SELECT *\r\n" + "FROM MEMBER";
		try {
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				MVO mvo = new MVO();
				mvo.setId(rs.getString("ID"));
				mvo.setPwd(rs.getString("PWD"));
				mvo.setName(rs.getString("NAME"));
				mvo.setMail(rs.getString("MAIL"));

				aList.add(mvo);
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return aList;
	}
}
