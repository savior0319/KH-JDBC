package memberView;

import java.util.Scanner;

import memberController.MCtrl;

public class MView {

	private Scanner sc = new Scanner(System.in);
	private MCtrl mc = new MCtrl();

	public MView() {

	}

	public void menu() {
		while (true) {
			System.out.println("1. 전체 회원 보기");
			System.out.println("2. 프로그램 종료");
			System.out.print("메뉴선택  >> ");
			switch (sc.nextInt()) {
			case 1:
				memberAll();
				break;
			case 2:
				System.out.println("\n※ 종료\n");
				System.exit(0);
			default:
				System.out.println("\n※잘못된 메뉴 선택\n");
				break;
			}
		}
	}

	public void memberAll() {
		System.out.println("\n──────────────────────────────────────────────────────────────");
		System.out.println("아이디\t비밀번호\t\t이름\t메일");
		System.out.println("──────────────────────────────────────────────────────────────");
		mc.memberAll();
		System.out.println("──────────────────────────────────────────────────────────────");
		System.out.println("※ 조회완료 \n");
	}
}
