package memberRun;

import memberView.MView;

public class MRun {
	public static void main(String[] args) {
		new MView().menu();
	}
}
