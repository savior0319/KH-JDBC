package mysql.jdbc.run;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class MysqlJDBCRun {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		while (true) {
			System.out.println("\n※ 메뉴");
			System.out.println("1. 전체 조회 ");
			System.out.println("2. 아이디로 조회 ");
			System.out.println("3. 프로그램 종료 ");
			System.out.print("메뉴선택 -> ");
			switch (sc.nextInt()) {
			case 1:
				selectAll();
				break;
			case 2:
				searchId();
				break;
			case 3:
				System.out.println("\n※ 종료합니다");
				System.exit(0);
			default:
				System.out.println("※ 메뉴를 잘못 입력했습니다");
				break;
			}
		}
	}

	public static void searchId() {

		System.out.print("검색할 아이디 입력 -> ");
		String id = sc.next();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://192.168.10.233:3306/jdbc", "student", "1q2w3e4r%T");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		Properties pp = new Properties();
		try {
			pp.load(new FileReader("C:\\workspace\\JDBCMYSQL\\src\\properties\\query.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		String query = pp.getProperty("searchId");
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			System.out.println("\n※ 회원 정보 조회");
			System.out.println("────────────────────────────────────────────");

			while (rs.next()) {
				System.out.println("아이디 -> " + rs.getString("member_id"));
				System.out.println("비밀번호 -> " + rs.getString("member_pwd"));
				System.out.println("이름 -> " + rs.getString("member_name"));
				String gender = rs.getString("gender");
				if (gender.equals("M")) {
					System.out.println("성별 -> 남");
				} else
					System.out.println("성별 -> 여");
				System.out.println("나이 -> " + rs.getInt("age") + "살");
				System.out.println("이메일 -> " + rs.getString("email"));
				System.out.println("전화번호 -> " + rs.getString("phone"));
				System.out.println("주소 -> " + rs.getString("address"));
				System.out.println("취미 -> " + rs.getString("hobby"));
				System.out.println("가입일 -> " + rs.getDate("enroll_date"));
			}
			System.out.println("────────────────────────────────────────────");
			System.out.println("※조회완료");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void selectAll() {

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://192.168.10.233:3306/jdbc", "student", "1q2w3e4r%T");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		Properties pp = new Properties();
		try {
			pp.load(new FileReader("C:\\workspace\\JDBCMYSQL\\src\\properties\\query.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		String query = pp.getProperty("selectAll");
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);

			System.out.println("\n※ 전체회원 조회");
			System.out.println("───────────────────────────────────────────────────────────────────────────");
			while (rs.next()) {
				System.out.print(rs.getString("member_id") + "  ");
				System.out.print(rs.getString("member_pwd") + "  ");
				System.out.print(rs.getString("member_name") + "  ");
				System.out.print(rs.getString("gender") + "  ");
				System.out.print(rs.getInt("age") + "  ");
				System.out.print(rs.getString("email") + "  ");
				System.out.print(rs.getString("phone") + "  ");
				System.out.print(rs.getString("address") + "  ");
				System.out.print(rs.getString("hobby") + "  ");
				System.out.print(rs.getDate("enroll_date") + "  ");
				System.out.println();
			}
			System.out.println("───────────────────────────────────────────────────────────────────────────");
			System.out.println("※조회완료");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
