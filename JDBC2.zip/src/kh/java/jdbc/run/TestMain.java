package kh.java.jdbc.run;

import kh.java.jdbc.view.MemberMenu;

public class TestMain {
	public static void main(String[] args) {
		new MemberMenu().mainMenu();
	}
}
