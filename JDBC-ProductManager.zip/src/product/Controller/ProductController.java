package product.Controller;

import java.util.ArrayList;

import product.model.VO.ProductVO;
import product.model.service.ProductService;

public class ProductController {

	private ProductService ps = new ProductService();

	public ProductController() {
	}

	public ArrayList<ProductVO> getProductAll() {
		ArrayList<ProductVO> aList = ps.getProductAll();
		if (aList.isEmpty()) {
			return null;
		} else
			return aList;
	}

	public ArrayList<ProductVO> searchProductId(String find) {
		ArrayList<ProductVO> aList = ps.searchProductId(find);
		if (aList.isEmpty()) {
			return null;
		} else
			return aList;
	}

	public ArrayList<ProductVO> searchProductName(String find) {
		ArrayList<ProductVO> aList = ps.searchProductName(find);
		if (aList.isEmpty()) {
			return null;
		} else
			return aList;
	}

	public int addProduct(ProductVO pv) {
		return ps.addProdcut(pv);
	}

	public int deleteProduct(String productId) {
		return ps.deleteProduct(productId);
	}

	public Object updateProduct(ProductVO pv, String updateProductId) {
		return ps.updateProduct(pv, updateProductId);
	}
}
