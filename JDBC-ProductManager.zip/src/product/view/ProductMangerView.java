package product.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

import product.Controller.ProductController;
import product.model.VO.ProductVO;

@SuppressWarnings("all")
public class ProductMangerView extends JFrame implements MouseListener, KeyListener {

	private ProductController pc = new ProductController();

	// 업데이트 제품 ID
	private String updateProductId;

	// 컨터이너
	private Container ct = getContentPane();

	// 라디오 버튼
	private JRadioButton jrbPID = new JRadioButton("Product ID");
	private JRadioButton jrbPName = new JRadioButton("Product Name");
	private ButtonGroup bg = new ButtonGroup();

	// 버튼
	private JButton jbtList = new JButton("전체 목록보기");
	private JButton jbtSearch = new JButton("검색");
	private JButton jbtAdd = new JButton("추가");
	private JButton jbtUpdate = new JButton("수정");
	private JButton jbtDelete = new JButton("삭제");

	// 라벨
	private JLabel jlbDetail = new JLabel("──── 상세 보기 ────");
	private JLabel jlbId = new JLabel("상품 ID : ");
	private JLabel jlbName = new JLabel("상 품 명 :");
	private JLabel jlbPrice = new JLabel("가   격");
	private JLabel jlbDesc = new JLabel("상품설명 : ");

	// 텍스트 필드
	private JTextField jtfSearchContent = new JTextField("");
	private JTextField jtfId = new JTextField();
	private JTextField jtfName = new JTextField();
	private JTextField jtfDesc = new JTextField();

	// 패널
	private JPanel jpEast = new JPanel();
	private JPanel jpEastUp = new JPanel();
	private JPanel jpEastUpNorth = new JPanel();
	private JPanel jpEastUpSouth = new JPanel();
	private JPanel jpEastDown = new JPanel();
	private JPanel jpEastDownNorth = new JPanel();
	private JPanel jpEastDownCenter = new JPanel();
	private JPanel jpEastDownSouth = new JPanel();
	private JPanel jpCenter = new JPanel();

	// 테이블
	private String[] columnNames = { "상품 ID", "상품 이름", "가격", "상품설명" };
	private Object[][] data;
	private DefaultTableModel dtm;
	private JTable jtb;
	private JScrollPane jsp;

	// 스피너
	private SpinnerModel spm = new SpinnerNumberModel(0, 0, 100000000, 50000);
	private JSpinner jspn = new JSpinner(spm);

	// 라디오 버튼 체크
	private boolean isRadioProductId = false;
	private boolean isRadioProductName = false;

	public ProductMangerView() {
	}

	public void view() {
		setTitle("상품 관리 프로그램");
		setVisible(true);
		setSize(850, 470);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// 테이블 셀 편집 x
		dtm = new DefaultTableModel(data, columnNames) {
			@Override
			public boolean isCellEditable(int data, int columnNames) {
				if (columnNames >= 0) {
					return false;
				} else {
					return true;
				}
			}
		};

		jtb = new JTable(dtm);
		jsp = new JScrollPane(jtb, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

		// 폰트설정
		jbtList.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jrbPID.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jrbPName.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jbtSearch.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jbtAdd.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jbtUpdate.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jbtDelete.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jlbDetail.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jlbId.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jlbName.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jlbPrice.setFont(new Font("맑은고딕", Font.PLAIN, 12));
		jlbDesc.setFont(new Font("맑은고딕", Font.PLAIN, 12));

		// 라디오 버튼 그룹
		bg.add(jrbPID);
		bg.add(jrbPName);

		// 검색 버튼 비활성화
		jbtSearch.setEnabled(false);

		// 레이아웃
		ct.setLayout(new BorderLayout());
		jpEast.setLayout(new BorderLayout());
		jpEastUp.setLayout(new BorderLayout());
		jpEastUpNorth.setLayout(new GridLayout(1, 3));
		jpEastUpSouth.setLayout(new BorderLayout());
		jpEastDown.setLayout(new BorderLayout());
		jpEastDownCenter.setLayout(new GridLayout(4, 2, 25, 25));
		jpEastDownSouth.setLayout(new GridLayout(1, 3, 10, 10));

		// 여백
		jpEastUpNorth.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		jpEastUp.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
		jpEastDownNorth.setBorder(BorderFactory.createEmptyBorder(20, 10, 0, 10));
		jpEastDownCenter.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
		jpEastDownSouth.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

		// 컴포넌트 추가
		jpEastUpNorth.add(jrbPID);
		jpEastUpNorth.add(jrbPName);
		jpEastUpNorth.add(jbtList);

		jpEastUpSouth.add(jtfSearchContent, BorderLayout.CENTER);
		jpEastUpSouth.add(jbtSearch, BorderLayout.EAST);

		jpEastUp.add(jpEastUpNorth, BorderLayout.NORTH);
		jpEastUp.add(jpEastUpSouth, BorderLayout.SOUTH);

		jpEastDownNorth.add(jlbDetail);
		jpEastDown.add(jpEastDownNorth, BorderLayout.NORTH);

		jpEastDownCenter.add(jlbId);
		jpEastDownCenter.add(jtfId);
		jpEastDownCenter.add(jlbName);
		jpEastDownCenter.add(jtfName);
		jpEastDownCenter.add(jlbPrice);
		jpEastDownCenter.add(jspn);
		jpEastDownCenter.add(jlbDesc);
		jpEastDownCenter.add(jtfDesc);

		jpEastDownSouth.add(jbtAdd);
		jpEastDownSouth.add(jbtUpdate);
		jpEastDownSouth.add(jbtDelete);

		jpEastDown.add(jpEastDownCenter, BorderLayout.CENTER);
		jpEastDown.add(jpEastDownSouth, BorderLayout.SOUTH);

		jpEast.add(jpEastUp, BorderLayout.NORTH);
		jpEast.add(jpEastDown, BorderLayout.CENTER);

		jpCenter.add(jsp);

		// 컨테이너 추가
		ct.add(jpCenter, BorderLayout.CENTER);
		ct.add(jpEast, BorderLayout.EAST);

		// 리스너 추가
		jtb.addMouseListener(this);
		jtfSearchContent.addKeyListener(this);
		jbtUpdate.addMouseListener(this);

		// product_id 라디오 버튼
		jrbPID.addActionListener(e -> {
			isRadioProductId = true;
			isRadioProductName = false;
			jbtSearch.setEnabled(true);
		});

		// product_name 라디오 버튼
		jrbPName.addActionListener(e -> {
			isRadioProductName = true;
			isRadioProductId = false;
			jbtSearch.setEnabled(true);
		});

		// 목록보기 버튼
		jbtList.addActionListener(e -> {
			getProductAll();
		});

		// 검색 버튼
		jbtSearch.addActionListener(e -> {
			if (jtfSearchContent.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "검색어를 입력해주세요", "검색", JOptionPane.ERROR_MESSAGE);
			} else {
				String find = jtfSearchContent.getText();
				if (isRadioProductId == true) {
					searchProductId(find);
				} else if (isRadioProductName == true) {
					searchProductName(find);
				}
			}
		});

		// 삭제 버튼
		jbtDelete.addActionListener(e -> {
			int deleteChk = JOptionPane.showConfirmDialog(null, "정말 삭제하시겠습니까?", "삭제", JOptionPane.YES_NO_OPTION,
					JOptionPane.WARNING_MESSAGE);
			if (deleteChk == 0) {
				deleteProduct();
			}
		});

		// 추가 버튼
		jbtAdd.addActionListener(e -> {
			addProduct();
		});

		// 수정 버튼
		jbtUpdate.addActionListener(e -> {
			updateProduct();
		});
	}

	// 제품 수정
	public void updateProduct() {

		ProductVO pv = new ProductVO();

		String productId = jtfId.getText();
		String productName = jtfName.getText();
		int price = (int) spm.getValue();
		String description = jtfDesc.getText();

		pv.setProductId(productId);
		pv.setpName(productName);
		pv.setPrice(price);
		pv.setDescription(description);

		Object object = pc.updateProduct(pv, updateProductId);

		if ((int) object > 0) {
			JOptionPane.showMessageDialog(null, "수정완료", "수정", JOptionPane.INFORMATION_MESSAGE);
			getProductAll();
		} else {
			JOptionPane.showMessageDialog(null, "수정실패", "수정", JOptionPane.ERROR_MESSAGE);
			getProductAll();
		}
	}

	// 제품 삭제
	public void deleteProduct() {

		int row = jtb.getSelectedRow();

		String productId = (String) jtb.getValueAt(row, 0);
		System.out.println(productId);

		int result = pc.deleteProduct(productId);

		if (result > 0) {
			JOptionPane.showMessageDialog(null, "상품을 삭제했습니다", "추가", JOptionPane.INFORMATION_MESSAGE);
			getProductAll();
		} else {
			JOptionPane.showMessageDialog(null, "상품 삭제에 실패했습니다", "추가", JOptionPane.ERROR_MESSAGE);
			getProductAll();
		}
	}

	// 제품 추가
	public void addProduct() {
		String productId = jtfId.getText();
		String pName = jtfName.getText();
		int price = (int) spm.getValue();
		String description = jtfDesc.getText();

		if (productId.equals("") || pName.equals("") || price == 0 || description.equals("")) {
			JOptionPane.showMessageDialog(null, "빈 항목이 있습니다", "추가", JOptionPane.ERROR_MESSAGE);
		} else {
			ProductVO pv = new ProductVO();
			pv.setProductId(productId);
			pv.setpName(pName);
			pv.setPrice(price);
			pv.setDescription(description);

			int result = pc.addProduct(pv);

			if (result > 0) {
				JOptionPane.showMessageDialog(null, "상품을 추가했습니다", "추가", JOptionPane.INFORMATION_MESSAGE);
				getProductAll();
			} else {
				JOptionPane.showMessageDialog(null, "상품 추가에 실패했습니다", "추가", JOptionPane.ERROR_MESSAGE);
				getProductAll();
			}
		}
	}

	// 제품 이름으로 검색
	public void searchProductName(String find) {

		dtm.setNumRows(0);

		ArrayList<ProductVO> aList = pc.searchProductName(find);
		if (aList == null) {
			JOptionPane.showMessageDialog(null, "상품정보가 없습니다", "검색", JOptionPane.ERROR_MESSAGE);
		} else {
			for (ProductVO p : aList) {
				dtm.addRow(new Object[] { p.getProductId(), p.getpName(), p.getPrice(), p.getDescription() });
			}
		}
	}

	// 제품 아이디로 검색
	public void searchProductId(String find) {

		dtm.setNumRows(0);

		ArrayList<ProductVO> aList = pc.searchProductId(find);
		if (aList == null) {
			JOptionPane.showMessageDialog(null, "상품정보가 없습니다", "검색", JOptionPane.ERROR_MESSAGE);
		} else {
			for (ProductVO p : aList) {
				dtm.addRow(new Object[] { p.getProductId(), p.getpName(), p.getPrice(), p.getDescription() });
			}
		}
	}

	// 목록 -> 테이블
	public void getProductAll() {

		dtm.setNumRows(0);

		ArrayList<ProductVO> aList = pc.getProductAll();
		if (aList == null) {
			JOptionPane.showMessageDialog(null, "상품정보가 없습니다", "상품정보", JOptionPane.ERROR_MESSAGE);
		} else {
			for (ProductVO p : aList) {
				dtm.addRow(new Object[] { p.getProductId(), p.getpName(), p.getPrice(), p.getDescription() });
			}
		}
	}

	// 셀 클릭 -> 텍스트필드
	@Override
	public void mouseClicked(MouseEvent e) {
		int row = jtb.getSelectedRow();
		if (e.getSource() == jtb) {
			String productId = (String) jtb.getValueAt(row, 0);
			String pName = (String) jtb.getValueAt(row, 1);
			int price = (int) jtb.getValueAt(row, 2);
			String description = (String) jtb.getValueAt(row, 3);

			// 업데이트 제품 아이디
			updateProductId = (String) jtb.getValueAt(row, 0);

			jtfId.setText(productId);
			jtfName.setText(pName);
			spm.setValue(price);
			jtfDesc.setText(description);
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {

	}

	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {

	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			jbtSearch.doClick();
		}

	}

	@Override
	public void keyReleased(KeyEvent e) {

	}
}
