package product.model.DAO;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import product.common.JDBCTemplate;
import product.model.VO.ProductVO;

@SuppressWarnings("all")

public class ProductDAO {
	private Statement stmt = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	private Properties pp = new Properties();

	public ProductDAO() {
		try {
			pp.load(new FileReader("C:\\workspace\\JDBC-ProductManager\\src\\properties\\query.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<ProductVO> getProductAll(Connection conn) {

		ArrayList<ProductVO> aList = new ArrayList<ProductVO>();

		String query = pp.getProperty("getProductAll");

		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				ProductVO pv = new ProductVO();
				pv.setProductId(rs.getString("PRODUCT_ID"));
				pv.setpName(rs.getString("P_NAME"));
				pv.setPrice(rs.getInt("PRICE"));
				pv.setDescription(rs.getString("DESCRIPTION"));

				aList.add(pv);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rs);
			JDBCTemplate.close(stmt);
		}
		return aList;
	}

	public ArrayList<ProductVO> searchProductId(Connection conn, String find) {

		ArrayList<ProductVO> aList = new ArrayList<ProductVO>();

		String query = pp.getProperty("searchProductId");

		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, "%" + find + "%");
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductVO pv = new ProductVO();
				pv.setProductId(rs.getString("PRODUCT_ID"));
				pv.setpName(rs.getString("P_NAME"));
				pv.setPrice(rs.getInt("PRICE"));
				pv.setDescription(rs.getString("DESCRIPTION"));

				aList.add(pv);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rs);
			JDBCTemplate.close(pstmt);
		}
		return aList;
	}

	public ArrayList<ProductVO> searchProductName(Connection conn, String find) {

		ArrayList<ProductVO> aList = new ArrayList<ProductVO>();

		String query = pp.getProperty("searchProductName");

		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, "%" + find + "%");
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductVO pv = new ProductVO();
				pv.setProductId(rs.getString("PRODUCT_ID"));
				pv.setpName(rs.getString("P_NAME"));
				pv.setPrice(rs.getInt("PRICE"));
				pv.setDescription(rs.getString("DESCRIPTION"));

				aList.add(pv);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rs);
			JDBCTemplate.close(pstmt);
		}
		return aList;
	}

	public int addProdcut(Connection conn, ProductVO pv) {

		int result = 0;

		String query = pp.getProperty("addProdcut");

		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, pv.getProductId());
			pstmt.setString(2, pv.getpName());
			pstmt.setInt(3, pv.getPrice());
			pstmt.setString(4, pv.getDescription());
			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		return result;
	}

	public int deleteProduct(Connection conn, String productId) {

		int result = 0;

		String query = pp.getProperty("deleteProduct");

		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, productId);
			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		return result;
	}

	public int updateProduct(Connection conn, ProductVO pv, String updateProductId) {

		int result = 0;

		String query = pp.getProperty("updateProduct");

		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, pv.getProductId());
			pstmt.setString(2, pv.getpName());
			pstmt.setInt(3, pv.getPrice());
			pstmt.setString(4, pv.getProductId());

			pstmt.setString(5, updateProductId);
			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		return result;
	}
}
