package product.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import product.common.JDBCTemplate;
import product.model.DAO.ProductDAO;
import product.model.VO.ProductVO;

public class ProductService {

	private ProductDAO pDao = new ProductDAO();
	private Connection conn = null;

	public ProductService() {
	}

	public ArrayList<ProductVO> getProductAll() {
		conn = JDBCTemplate.getConnect(conn);
		ArrayList<ProductVO> aList = pDao.getProductAll(conn);
		JDBCTemplate.close(conn);
		return aList;
	}

	public ArrayList<ProductVO> searchProductId(String find) {
		conn = JDBCTemplate.getConnect(conn);
		ArrayList<ProductVO> aList = pDao.searchProductId(conn, find);
		JDBCTemplate.close(conn);
		return aList;
	}

	public ArrayList<ProductVO> searchProductName(String find) {
		conn = JDBCTemplate.getConnect(conn);
		ArrayList<ProductVO> aList = pDao.searchProductName(conn, find);
		JDBCTemplate.close(conn);
		return aList;
	}

	public int addProdcut(ProductVO pv) {
		conn = JDBCTemplate.getConnect(conn);
		int result = pDao.addProdcut(conn, pv);
		if(result > 0) {
			JDBCTemplate.commit(conn);
		} else JDBCTemplate.rollBack(conn);
		JDBCTemplate.close(conn);
		return result;
	}

	public int deleteProduct(String productId) {
		conn = JDBCTemplate.getConnect(conn);
		int result = pDao.deleteProduct(conn, productId);
		if(result > 0) {
			JDBCTemplate.commit(conn);
		} else JDBCTemplate.rollBack(conn);
		JDBCTemplate.close(conn);
		return result;
	}

	public Object updateProduct(ProductVO pv, String updateProductId) {
		conn = JDBCTemplate.getConnect(conn);
		int result = pDao.updateProduct(conn, pv, updateProductId);
		if(result > 0) {
			JDBCTemplate.commit(conn);
		} else JDBCTemplate.rollBack(conn);
		JDBCTemplate.close(conn);
		return result;
	}
}
