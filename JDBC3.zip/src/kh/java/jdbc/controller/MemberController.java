
/*
 * View에서 요청이 들어온 작업은
 * Controller에서 DAO로 요청 작업을 해야함
 */

package kh.java.jdbc.controller;

import java.util.ArrayList;

import kh.java.jdbc.model.service.MemberService;
import kh.java.jdbc.model.vo.Member;

public class MemberController {
	ArrayList<Member> list = new ArrayList<Member>();

	Member m = null;

	MemberService mService = new MemberService();

	// 기본 생성자
	public MemberController() {

	}

	// 회원 전체를 출력하는 selectAll 메소드 - DAO에서 DB로 받아온 데이터를 list에 넘겨받음
	public ArrayList<Member> selectAll() {
		list = new MemberService().selectALL();

		// DAO에서 넘어온 list가 비워져 있다면
		if (list.isEmpty()) {
			return null;

			// list안에 데이터가 있다면
		} else {
			return list;
		}
	}

	// 회원 한명을 출력하는 selectOneId 메소드 - DAO에서 DB로 받아온 데이터를 변수 M에 넘겨받음
	public Member selectOneId(String memberId) {
		m = mService.selectOneId(memberId);
		return m;
	}

	public ArrayList<Member> selectName(String MemberName) {
		list = mService.selectName(MemberName);
		if (list.isEmpty()) {
			return null;
		} else {
			return list;
		}
	}

	public int insertMember(Member m) {
		int result = mService.insertMember(m);
		return result;
	}

	public int updateMember(Member m) {
		int result = mService.updateMember(m);
		return result;
	}

	public int deleteMember(String MemberId) {
		int result = mService.deleteMember(MemberId);
		return result;
	}
}
