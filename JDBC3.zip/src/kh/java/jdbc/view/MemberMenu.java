package kh.java.jdbc.view;

import java.util.ArrayList;
import java.util.Scanner;

import kh.java.jdbc.controller.MemberController;
import kh.java.jdbc.model.vo.Member;

public class MemberMenu {

	private Scanner sc = new Scanner(System.in);
	private ArrayList<Member> list = new ArrayList<Member>();
	private MemberController memCon = new MemberController();
	private Member m = null;

	public MemberMenu() {

	}

	public void mainMenu() {

		while (true) {
			int select;

			System.out.println("\n = = = = = = 회원 관리 프로그램 = = = = = = = ");
			System.out.println("1. 회원 정보 전체 조회");
			System.out.println("2. 회원 아이디 조회");
			System.out.println("3. 회원 이름으로 조회");
			System.out.println("4. 회원 가입");
			System.out.println("5. 회원 정보 변경");
			System.out.println("6. 회원 탈퇴");
			System.out.println("0. 프로그램 종료");
			System.out.print("선택(0~6) : ");

			select = sc.nextInt();

			switch (select) {
			case 1:
				selectAll();
				break;

			case 2:
				selectOneId();
				break;

			case 3:
				selectName();
				break;

			case 4:
				insertMember();
				break;

			case 5:
				updateMember();
				break;

			case 6:
				deleteMember();
				break;

			case 0:
				char end = sc.next().toUpperCase().charAt(0);

				System.out.println("정말 끝내시겠습니까?(y,n)");
				if (end == 'Y')
					return;
				else if (end == 'N')
					break;
				else
					System.out.println("Y 또는 N만 입력해주세요.");

			default:
				System.out.println("번호를 잘못 선택하셨습니다.");

			}
		}
	}

	public void selectAll() {
		list = new MemberController().selectAll();
		if (list == null) {
			System.out.println("요청한 정보가 없습니다.");
		} else {
			System.out.println("= = = = = = 전체 회원 조회 = = = = =");
			System.out.println("아이디  이름  성별  나이  이메일  전화번호  주소  취미  가입일");

			for (Member m : list) {
				System.out.println(m);
			}
		}
		memCon.selectAll();
	}

	public void selectOneId() {
		System.out.println("찾으시려는 아이디를 입력해주세요.");
		String memberId = sc.next();
		m = memCon.selectOneId(memberId);
		if (m == null) {
			System.out.println("데이터가 없습니다.");
		} else {
			System.out.println("--------< 회원조회 > ---------");
			System.out.println("아이디 : " + m.getMemberId());
			System.out.println("비밀번호 : " + m.getMemberPwd());
			System.out.println("이름 : " + m.getMemberName());
			System.out.println("나이 : " + m.getAge());
			System.out.print("성별 : ");
			if (m.getGender().equals("M"))
				System.out.println("남");
			if (m.getGender().equals("F"))
				System.out.println("여");
			System.out.println("이메일 : " + m.getEmail());
			System.out.println("휴대폰 : " + m.getPhone());
			System.out.println("주소 : " + m.getAddress());
			System.out.println("취미 : " + m.getHobby());
			System.out.println("가입일 : " + m.getEnrollDate());

		}
	}

	public void selectName() {
		System.out.print("이름 검색 : ");
		String MemberName = sc.next();

		list = memCon.selectName(MemberName);

		if (list == null) {
			System.out.println("데이터가 없습니다.");
		} else {
			System.out.println("= = = = = = 회원 조회 = = = = =");
			System.out.println("아이디  이름  성별  나이  이메일  전화번호  주소  취미  가입일");
			for (Member m : list) {
				System.out.println(m);
			}
		}
	}

	public void insertMember() {
		Member m = new Member();
		System.out.println("-------회원가입-------");
		System.out.print("아이디 입력 : ");
		m.setMemberId(sc.next());
		System.out.print("패스워드 입력 : ");
		m.setMemberPwd(sc.next());
		System.out.print("이름 입력 : ");
		m.setMemberName(sc.next());
		System.out.print("성별(남/여) 입력 : ");
		String gender = sc.next();
		if (gender.equals("남"))
			m.setGender("M");
		else if (gender.equals("여"))
			m.setGender("F");
		System.out.print("나이 입력 : ");
		m.setAge(sc.nextInt());
		System.out.print("메일 입력 : ");
		m.setEmail(sc.next());
		sc.nextLine();
		System.out.print("주소 입력 : ");
		m.setAddress(sc.nextLine());
		System.out.println("전화번호(-빼고) 입력 : ");
		m.setPhone(sc.next());
		System.out.println("취미 입력(,로 공백없이 나열) : ");
		m.setHobby(sc.next());
		int result = memCon.insertMember(m);
		if (result == 0) {
			System.out.println("회원가입에 실패했습니다.");
		} else {
			System.out.println("회원가입에 성공했습니다.");
		}
	}

	public void updateMember() {
		Member m = null;
		System.out.println("찾으시려는 아이디를 입력해주세요.");
		String memberId = sc.next();
		m = memCon.selectOneId(memberId);
		if (m != null) {
			System.out.println("수정할 정보 입력 ");
			System.out.println("새 암호 입력 : ");
			m.setMemberPwd(sc.next());
			System.out.println("새 이메일 입력 : ");
			m.setEmail(sc.next());
			sc.nextLine();
			System.out.println("새 주소 입력 : ");
			m.setAddress(sc.nextLine());
			m.setMemberId(memberId);
			int result = memCon.updateMember(m);
			if (result > 0) {
				System.out.println("업데이트가 성공적으로 완료되었습니다.");
			} else {
				System.out.println("업데이트 실패!");
			}
		} else {
			System.out.println("회원이 존재하지 않습니다");
		}
	}

	public void deleteMember() {
		Member m = null;
		System.out.println("회원 아이디 입력");
		String memberId = sc.next();
		m = memCon.selectOneId(memberId);
		if (m != null) {
			System.out.println("정말로 탈퇴하시겠습니까?(y,n)");
			if (sc.next().toUpperCase().charAt(0) == 'Y') {
				int result = memCon.deleteMember(memberId);
				if (result >= 2) {
					System.out.println("성공적으로 삭제가 완료되었습니다.");
				} else {
					System.out.println("실패!");
				}
			} else {
				System.out.println("탈퇴를 취소합니다.");
			}
		} else {
			System.out.println("회원이 존재하지 않습니다.");
		}
	}
}
