package kh.java.jdbc.controller;

import java.util.ArrayList;

import kh.java.jdbc.model.service.MemberService;
import kh.java.jdbc.model.vo.Member;

public class MemberController {
	private ArrayList<Member> list = new ArrayList<Member>();
	private Member m = null;
	private MemberService mService = new MemberService();

	public MemberController() {

	}

	public ArrayList<Member> selectAll() {
		list = new MemberService().selectALL();
		if (list.isEmpty()) {
			return null;

		} else {
			return list;
		}
	}

	public Member selectOneId(String memberId) {
		m = mService.selectOneId(memberId);
		return m;
	}

	public ArrayList<Member> selectName(String MemberName) {
		list = mService.selectName(MemberName);
		if (list.isEmpty()) {
			return null;
		} else {
			return list;
		}
	}

	public int insertMember(Member m) {
		int result = mService.insertMember(m);
		return result;
	}

	public int updateMember(Member m) {
		int result = mService.updateMember(m);
		return result;
	}

	public int deleteMember(String MemberId) {
		int result = mService.deleteMember(MemberId);
		return result;
	}
}
