package kh.mb.run;

import kh.mb.view.MemberBoardView;

public class Run {
	public static void main(String[] args) {
		new MemberBoardView().menu();
	}
}
